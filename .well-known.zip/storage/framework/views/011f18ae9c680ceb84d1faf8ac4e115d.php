<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="row ">


                <div class="card col m-2" style="width: 18rem;">
                    <!-- Enlace que envuelve la imagen -->
                    <a href="<?php echo e(route('margen-bruto')); ?>">
                        <img src="<?php echo e(asset('storage/images/imgMB.png')); ?>" class="card-img-top" alt="Margen Bruto">
                    </a>
                    <div class="card-body">
                        <p class="card-text">
                            En el Margen Bruto se podrá ver lo proyectado vs lo actualizado, con la posibilidad de poder filtrar por cosecha, cultivo, campo, etc. Además, podrá navegar entre cada detalle de información brindada.
                        </p>
                    </div>
                </div>

                <div class="card col m-2" style="width: 18rem;">
                    <a href="<?php echo e(route('cosecha')); ?>">
                         <img src="<?php echo e(asset('storage/images/ReporteLogistica.png')); ?>" class="card-img-top" alt="...">
                    </a>
                    <div class="card-body">
                        <p class="card-text">En desarrollo: Cosecha. Relaciona datos de App Finap, Finnegans y pagina de Mader.</p>
                    </div>
                </div>

                 <?php if(Auth::user()->role_id !== 4): ?><!-- Si el usuario no es invitado (id 4) -->
                <div class="card col m-2" style="width: 18rem;">

                        <img src="<?php echo e(asset('storage/images/images (1).jpeg')); ?>" class="card-img-top" alt="...">

                    <div class="card-body">
                        <p class="card-text">Proximamente Flujo de fondo.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-warning" role="alert">
                    Vista Solamente para Administradores y Editores
                </div>
            <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TAGUAY\taguay\resources\views\home.blade.php ENDPATH**/ ?>