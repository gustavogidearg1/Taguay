    <style>
        /* Asegúrate de que el body y html ocupen el 100% del alto */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow: hidden; /* Evita barras de desplazamiento */
        }

        /* Contenedor principal del iframe */
        .iframe-container {
            position: ;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        /* Asegúrate de que el iframe ocupe el 100% del contenedor */
        .iframe-container iframe {
            width: 100%;
            height: 90%;
            border: none; /* Elimina el borde predeterminado del iframe */
        }
    </style>

    <!-- Contenedor para el iframe -->
    <div class="iframe-container">
            <!-- Botón para mostrar/ocultar la sección -->
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Volver</a>


        <iframe
            title="Presupuestacion_Taguay-V5"
            src="https://app.powerbi.com/view?r=eyJrIjoiMTE0MDg3ODEtZTQ5ZS00ZWNlLTg4ZWUtOGJmZTA3YWI5YjEwIiwidCI6ImZmZDgyMjAxLWJjNzUtNDA5OS05MjkzLWRlNDdiMzkyNmM5YiIsImMiOjR9"
            allowFullScreen="true">
        </iframe>
    </div>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TAGUAY\taguay\resources\views\components\MargenBruto.blade.php ENDPATH**/ ?>