<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home1/taguay/sistema.taguay.com.ar/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>