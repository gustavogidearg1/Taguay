<?php echo e($slot); ?>

<?php /**PATH /home1/taguay/sistema.taguay.com.ar/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>