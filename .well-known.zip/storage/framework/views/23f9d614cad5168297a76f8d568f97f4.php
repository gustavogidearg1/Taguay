<!-- resources/views/components/menu.blade.php -->
<header class="bg-white shadow-sm">
    <div class="container mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <!-- Logo a la izquierda -->
            <div class="flex items-center">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('storage/images/logo-taguay.png')); ?>" alt="Logo" class="h-10">
                </a>
            </div>

            <!-- Menú de navegación a la derecha -->
            <nav class="flex items-center space-x-4">
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <!-- Botón Dashboard (si el usuario está autenticado) -->
                        <a
                            href="<?php echo e(url('/home')); ?>"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                        >
                            Dashboard
                        </a>
                    <?php else: ?>
                        <!-- Botón Acceso (si el usuario no está autenticado) -->
                        <a
                            href="<?php echo e(route('login')); ?>"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                        >
                            Acceso
                        </a>

                        <!-- Botón Registro (si la ruta de registro está disponible) -->
                        <?php if(Route::has('register')): ?>
                        <!--
                            <a
                                href="<?php echo e(route('register')); ?>"
                                class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                            >
                                Registro
                            </a>
                        -->

                        <a
                        href="mailto:lcingolani@taguay.com.ar"
                        class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                    >
                        Solicitar Registro
                    </a>



                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\TAGUAY\taguay\resources\views/layouts/menu.blade.php ENDPATH**/ ?>