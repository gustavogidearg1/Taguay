<!-- resources/views/welcome.blade.php -->
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Taguay')); ?>: Welcome</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Styles / Scripts -->
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
        <?php endif; ?>
    </head>
    <body class="font-sans antialiased">
        <!-- Incluir el menú -->
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Contenido de la página -->
        <div class="min-h-screen bg-gray-100">
            <div class="container mx-auto px-6 py-8">
                <h1 class="text-3xl font-bold text-gray-900">Bienvenido al sistema de Taguay</h1>
                <p class="mt-4 text-gray-600">
                    Si ya tienes un usuario y contraseña, por favor
                    <a href="<?php echo e(route('login')); ?>" class="text-blue-600 hover:underline">accede aquí</a>.
                    Si no tienes acceso, solicítalo a
                    <a href="mailto:lcingolani@taguay.com.ar" class="text-blue-600 hover:underline">lcingolani@taguay.com.ar</a>.
                    ¡Gracias!
                </p>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\TAGUAY\taguay\resources\views\welcome.blade.php ENDPATH**/ ?>