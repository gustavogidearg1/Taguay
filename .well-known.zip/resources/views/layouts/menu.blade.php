<!-- resources/views/components/menu.blade.php -->
<header class="bg-white shadow-sm">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="container mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <!-- Logo a la izquierda -->
            <div class="flex items-center">
                <a href="{{ url('/') }}">
                    <img src="{{ asset('storage/images/logo-taguay.png') }}" alt="Logo" class="h-10">
                </a>
            </div>

            <!-- Menú de navegación a la derecha -->
            <nav class="flex items-center space-x-4">
                @if (Route::has('login'))
                    @auth
                        <!-- Botón Dashboard (si el usuario está autenticado) -->
                        <a
                            href="{{ url('/home') }}"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                        >
                            Dashboard
                        </a>
                    @else
                        <!-- Botón Acceso (si el usuario no está autenticado) -->
                        <a
                            href="{{ route('login') }}"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                        >
                            Acceso
                        </a>

                        <!-- Botón Registro (si la ruta de registro está disponible) -->
                        @if (Route::has('register'))
                        <!--
                            <a
                                href="{{ route('register') }}"
                                class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                            >
                                Registro
                            </a>
                        -->

                        <a
                        href="mailto:lcingolani@taguay.com.ar"
                        class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                    >
                        Solicitar Registro
                    </a>



                        @endif
                    @endauth
                @endif
            </nav>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</header>
