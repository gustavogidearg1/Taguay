<?php
header('Content-Type: application/json');
echo json_encode([
    'server_software' => $_SERVER['SERVER_SOFTWARE'],
    'request_uri' => $_SERVER['REQUEST_URI'],
    'script_name' => $_SERVER['SCRIPT_NAME'],
    'php_self' => $_SERVER['PHP_SELF'],
    'document_root' => $_SERVER['DOCUMENT_ROOT']
]);