<?php

use App\Http\Controllers\CosechaController;
use App\Http\Controllers\FlujoFondoController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\MargenBrutoController;
use App\Http\Controllers\TaguayController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Auth; // <-- A�ade esta l�nea
use Illuminate\Support\Facades\Route;

// Ruta de prueba simple - Sin middleware, sin controlador
Route::get('/test-users', function() {
    return response()->json([
        'status' => 'success',
        'message' => 'Esta es una prueba simple',
        'data' => [
            'user_agent' => request()->header('User-Agent'),
            'current_url' => url()->current()
        ]
    ]);
});

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/margen-bruto', [MargenBrutoController::class, 'index'])->name('margen-bruto');


// Ruta para la p�gina de Cosecha
Route::get('/cosecha', [CosechaController::class, 'index'])->name('cosecha');

// Ruta para la p�gina de Flujo de Fondo
Route::get('/flujo-fondo', [FlujoFondoController::class, 'index'])->name('flujo-fondo');

// Definir la ruta para acceder al JSON
Route::get('/getJsonData', [TaguayController::class, 'getJsonData']);


Route::middleware(['auth'])->group(function () {
    // Otras rutas...
    
    // Versi�n simplificada para diagn�stico
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    
    // Comenta temporalmente las otras rutas de users
    // Route::resource('users', UserController::class)
    //      ->middleware('can:viewAny,App\Models\User');
});

Route::get('/test-users', function() {
    return 'Ruta de prueba alcanzada';
});
